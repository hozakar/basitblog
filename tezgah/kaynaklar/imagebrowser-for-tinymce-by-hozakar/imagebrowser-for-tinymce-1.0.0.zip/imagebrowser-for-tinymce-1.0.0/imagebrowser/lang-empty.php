<?php

/*
**  Image Browser 1.0.0
**  Plugin for TinyMCE
**  https://github.com/hozakar/imagebrowser-for-tinymce
**
**  Copyright 2014, Hakan Özakar
**  http://beltslib.net
**
**  Licensed under CC0 1.0 Universal Licence:
**  https://creativecommons.org/publicdomain/zero/1.0/
*/

    $translate = array(
        "Directory could not be deleted!"                   => "",
        "Image"                                             => "",
        "Float"                                             => "",
        "Width"                                             => "",
        "Free"                                              => "",
        "None"                                              => "",
        "Left"                                              => "",
        "Right"                                             => "",
        "Alt"                                               => "",
        "UPLOAD"                                            => "",
        "DELETE"                                            => "",
        "CUT"                                               => "",
        "COPY"                                              => "",
        "PASTE"                                             => "",
        "Add Directory"                                     => "",
        "Delete"                                            => "",
        "Are You Sure You Want To Delete This Directory?"   => "",
        "Are you sure you want to delete this file?"        => "",
        "Are you sure you want to delete selected file(s)?" => ""
    );
?>