###What is imgfix?###

Imgfix is a simple tool for dynamicaly sizing images and applying hover effects while displaying. Especially usefull with grids and galleries.

###How does it work?###

Imgfix re-organizes containing elements and dynamically applies CSS properties to relevant layers and images.

For demos and detailed information on how to use please visit [imgfix.beltslib.net](http://imgfix.beltslib.net)
